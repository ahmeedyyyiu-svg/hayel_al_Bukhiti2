// واجهة التطبيق: كل شيء يعمل محليًا (localStorage) بدون أي طلبات شبكة،
// حتى يعمل التطبيق بدون اتصال بالإنترنت داخل تطبيق أندرويد المُعبّأ.
const contactsList = document.getElementById("contacts-list");
const contactsEmpty = document.getElementById("contacts-empty");
const contactsCount = document.getElementById("contacts-count");

const addForm = document.getElementById("add-contact-form");
const addMessage = document.getElementById("add-contact-message");

const importForm = document.getElementById("import-form");
const importMessage = document.getElementById("import-message");

const selectAllCheckbox = document.getElementById("select-all");
const bulkMessageInput = document.getElementById("bulk-message");
const sendBulkBtn = document.getElementById("send-bulk-btn");
const sendSummary = document.getElementById("send-summary");
const sendStatusList = document.getElementById("send-status-list");

function setMessage(el, text, type) {
  el.textContent = text;
  el.className = "message" + (type ? ` ${type}` : "");
}

let latestContacts = [];

function renderContacts(contacts) {
  latestContacts = contacts;
  contactsCount.textContent = contacts.length;
  contactsList.innerHTML = "";

  if (contacts.length === 0) {
    contactsEmpty.style.display = "block";
    selectAllCheckbox.checked = false;
    return;
  }
  contactsEmpty.style.display = "none";

  for (const contact of contacts) {
    const li = document.createElement("li");
    li.className = "contact-item";
    li.innerHTML = `
      <label class="checkbox-label contact-select">
        <input type="checkbox" class="contact-checkbox" data-id="${contact.id}" />
      </label>
      <div class="contact-info">
        <span class="contact-name"></span>
        <span class="contact-phone"></span>
      </div>
      <button class="delete-btn" data-id="${contact.id}">حذف</button>
    `;
    li.querySelector(".contact-name").textContent = contact.name;
    li.querySelector(".contact-phone").textContent = contact.phone;
    contactsList.appendChild(li);
  }
}

function loadContacts() {
  renderContacts(ContactsStore.getAll());
}

addForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const name = document.getElementById("name").value.trim();
  const phone = document.getElementById("phone").value.trim();

  try {
    ContactsStore.addContact(name, phone);
  } catch (err) {
    setMessage(addMessage, err.message || "حدث خطأ", "error");
    return;
  }
  setMessage(addMessage, "تم حفظ جهة الاتصال بنجاح!", "success");
  addForm.reset();
  loadContacts();
});

contactsList.addEventListener("click", (e) => {
  const btn = e.target.closest(".delete-btn");
  if (!btn) return;
  ContactsStore.removeContact(btn.dataset.id);
  loadContacts();
});

const csvFileInput = document.getElementById("csv-file");
const csvFileName = document.getElementById("csv-file-name");

csvFileInput.addEventListener("change", () => {
  csvFileName.textContent = csvFileInput.files.length
    ? csvFileInput.files[0].name
    : "لم يتم اختيار ملف";
});

function readFileAsText(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(reader.error);
    reader.readAsText(file, "utf-8");
  });
}

importForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const fileInput = document.getElementById("csv-file");
  if (!fileInput.files.length) return;

  setMessage(importMessage, "جاري الاستيراد...", "");

  let rows;
  try {
    const text = await readFileAsText(fileInput.files[0]);
    rows = parseContactsCsv(text);
  } catch (err) {
    setMessage(importMessage, "تعذر قراءة ملف CSV، تأكد من صيغة الملف", "error");
    return;
  }

  if (rows.length === 0) {
    setMessage(importMessage, "الملف لا يحتوي على بيانات", "error");
    return;
  }

  const { added, skipped } = ContactsStore.importContacts(rows);
  const parts = [`تمت إضافة ${added.length} جهة اتصال`];
  if (skipped.length > 0) {
    parts.push(`وتخطي ${skipped.length} (مكررة أو ناقصة)`);
  }
  setMessage(importMessage, parts.join(" "), "success");
  importForm.reset();
  csvFileName.textContent = "لم يتم اختيار ملف";
  loadContacts();
});

selectAllCheckbox.addEventListener("change", () => {
  document.querySelectorAll(".contact-checkbox").forEach((cb) => {
    cb.checked = selectAllCheckbox.checked;
  });
});

function getSelectedContacts() {
  const ids = Array.from(document.querySelectorAll(".contact-checkbox:checked")).map((cb) =>
    Number(cb.dataset.id)
  );
  return latestContacts.filter((c) => ids.includes(c.id));
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function renderSendStatus(statuses) {
  sendStatusList.innerHTML = "";
  for (const s of statuses) {
    const li = document.createElement("li");
    li.className = `send-status-item send-status-${s.state}`;
    const label =
      s.state === "pending"
        ? "قيد الانتظار"
        : s.state === "sending"
        ? "جارٍ الإرسال..."
        : s.state === "sent"
        ? "تم الإرسال"
        : `فشل${s.reason ? `: ${s.reason}` : ""}`;
    li.innerHTML = `
      <span class="send-status-name"></span>
      <span class="send-status-state"></span>
    `;
    li.querySelector(".send-status-name").textContent = `${s.contact.name} (${s.contact.phone})`;
    li.querySelector(".send-status-state").textContent = label;
    sendStatusList.appendChild(li);
  }
}

// يرسل الرسالة إلى جهات الاتصال المحدّدة واحدة تلو الأخرى، بفارق ٣ ثوانٍ
// بين كل رسالة والتالية (الانتظار يبدأ بعد اكتمال إرسال الرسالة الحالية).
// الإرسال الفعلي يتم عبر smsBridge.js: يعمل فقط داخل تطبيق أندرويد
// المُعبّأ (بعد تركيب إضافة SMS أصلية)، ويظهر "غير متصل" داخل المتصفح.
async function sendBulkSequential() {
  const message = bulkMessageInput.value.trim();
  const selected = getSelectedContacts();

  if (!message) {
    setMessage(sendSummary, "يرجى كتابة نص الرسالة أولاً", "error");
    return;
  }
  if (selected.length === 0) {
    setMessage(sendSummary, "يرجى تحديد جهة اتصال واحدة على الأقل", "error");
    return;
  }

  sendBulkBtn.disabled = true;
  const statuses = selected.map((contact) => ({ contact, state: "pending" }));
  renderSendStatus(statuses);
  setMessage(sendSummary, `جارٍ الإرسال: 0 من ${statuses.length}`, "");

  let sentCount = 0;
  let failedCount = 0;

  for (let i = 0; i < statuses.length; i++) {
    statuses[i].state = "sending";
    renderSendStatus(statuses);

    try {
      const result = await sendSms(statuses[i].contact, message);
      if (result.success) {
        statuses[i].state = "sent";
        sentCount += 1;
      } else {
        statuses[i].state = "failed";
        statuses[i].reason = result.message || "خطأ غير معروف";
        failedCount += 1;
      }
    } catch (err) {
      statuses[i].state = "failed";
      statuses[i].reason = "خطأ غير متوقع أثناء الإرسال";
      failedCount += 1;
    }

    renderSendStatus(statuses);
    setMessage(
      sendSummary,
      `جارٍ الإرسال: ${i + 1} من ${statuses.length} (نجح ${sentCount}، فشل ${failedCount})`,
      ""
    );

    const isLast = i === statuses.length - 1;
    if (!isLast) {
      await sleep(3000);
    }
  }

  sendBulkBtn.disabled = false;
  setMessage(
    sendSummary,
    `اكتمل الإرسال: نجح ${sentCount} من ${statuses.length}، فشل ${failedCount}`,
    failedCount > 0 ? "error" : "success"
  );
}

sendBulkBtn.addEventListener("click", sendBulkSequential);

loadContacts();

// تسجيل عامل الخدمة (Service Worker) ليعمل التطبيق بدون إنترنت بعد أول
// زيارة، وليصبح قابلًا للتثبيت على الهاتف من المتصفح (PWA) بانتظار بناء
// الـ APK الفعلي عبر Capacitor.
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/service-worker.js").catch((err) => {
      console.error("تعذر تسجيل عامل الخدمة", err);
    });
  });
}
