// تخزين جهات الاتصال محليًا على الجهاز نفسه (localStorage) بدل الاعتماد على
// خادم بعيد. هذا ما يجعل التطبيق يعمل بالكامل بدون اتصال بالإنترنت
// (Offline) عند تعبئته كتطبيق أندرويد عبر Capacitor، وأيضًا يعمل بنفس
// الطريقة هنا داخل معاينة Replit للاختبار.

const STORAGE_KEY = "smsManagerContacts";

function readAll() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (err) {
    console.error("تعذرت قراءة جهات الاتصال المخزّنة محليًا", err);
    return [];
  }
}

function writeAll(contacts) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(contacts));
}

function nextId(contacts) {
  return contacts.reduce((max, c) => Math.max(max, c.id), 0) + 1;
}

function normalizePhone(phone) {
  return String(phone || "").trim();
}

const ContactsStore = {
  getAll() {
    return readAll().sort((a, b) => a.id - b.id);
  },

  addContact(name, phone) {
    const contacts = readAll();
    const trimmedPhone = normalizePhone(phone);
    if (contacts.some((c) => c.phone === trimmedPhone)) {
      const err = new Error("رقم الهاتف موجود مسبقًا");
      err.code = "DUPLICATE";
      throw err;
    }
    const contact = {
      id: nextId(contacts),
      name: String(name).trim(),
      phone: trimmedPhone,
      createdAt: new Date().toISOString(),
    };
    contacts.push(contact);
    writeAll(contacts);
    return contact;
  },

  // يستورد مجموعة صفوف { name, phone }، ويتخطى المكرر أو الناقص منها.
  importContacts(rows) {
    const contacts = readAll();
    const existingPhones = new Set(contacts.map((c) => c.phone));
    let counter = nextId(contacts);
    const added = [];
    const skipped = [];

    for (const row of rows) {
      const name = String(row.name || "").trim();
      const phone = normalizePhone(row.phone);
      if (!name || !phone || existingPhones.has(phone)) {
        skipped.push(row);
        continue;
      }
      const contact = { id: counter++, name, phone, createdAt: new Date().toISOString() };
      contacts.push(contact);
      existingPhones.add(phone);
      added.push(contact);
    }

    writeAll(contacts);
    return { added, skipped };
  },

  removeContact(id) {
    const contacts = readAll();
    const targetId = Number(id);
    const index = contacts.findIndex((c) => c.id === targetId);
    if (index === -1) return false;
    contacts.splice(index, 1);
    writeAll(contacts);
    return true;
  },
};

window.ContactsStore = ContactsStore;
